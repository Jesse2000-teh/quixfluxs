const Loader = () => {
  return (
    <div className="flex h-screen items-center justify-center">
      <svg className="loader_svg fill-[#008efb]" viewBox="25 25 50 50">
        <circle r="20" cy="50" cx="50"></circle>
      </svg>
    </div>
  );
};

export default Loader;
