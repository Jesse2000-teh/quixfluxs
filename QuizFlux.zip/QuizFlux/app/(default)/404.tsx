/** @format */

import PageNotFound from "@/components/ui/PageNotFound";
import React from "react";

export default function NotFound() {
  return <PageNotFound />;
}
